# Wellinks React Component Library
This repo will serve as the primary development point for all proprietary components made at Wellinks and their tests. Note: due to an issue with styled components, components in this library will only work rendered client side. Server side rendering is broken. See here: [MaterialUi Styled Components Guide](https://mui.com/material-ui/guides/styled-engine/)
```
Using styled-components as an engine at this moment is not working when used in a SSR projects. The reason is that the babel-plugin-styled-components is not picking up correctly the usages of the styled() utility inside the @mui packages. For more details, take a look at this issue. We strongly recommend using Emotion for SSR projects.
```
## Toolchain
- Yarn -> package manager
- Rollup -> webpack but for modules
- Babel -> compiler allowing us to write modern JS
- Typescript -> because we are people of culture
- React -> to make self contained testable components
- MaterialUI (styled-components) -> freshly baked sophisticated components fresh from the oven
- Styled-Components -> In line styling for react components
- Sass -> Styling
- ESLint -> linter
- Prettier -> code formatter
## Getting started with development
1. clone the repo
2. cd into the repo and run `yarn install` to download all the package dependencies
3. `yarn rollup` will bundle 'build' the project into an ESM module
4. `yarn test` fires the Jest test suite
5. `yarn lint` runs ESLint
6. `yarn lint:fix` runs ESLint and fixes issues
7. `yarn format` runs prettier
8. `yarn storybook` to run storybook
## Deployment
1. Push and merge your changes including an update to the version number in package.json
2. In git, cut a new release with a new tag matching the version number
3. Let Github Actions take it from there
## Importing the library
In the project you're importing into:
1. in github go to your account settings > developer settings > personal access tokens > Tokens (classic)
2. click generate new token
3. in the permissions list check write:packages
4. repo permissions should automatically be toggled when you enable the write:packages permission
5. click generate and copy the output token to your clipboard
1. In the root of your project make a file named .npmrc
2. Copy the following into the file
```
//npm.pkg.github.com/:_authToken=<YOUR_GIT_AUTH_TOKEN>
@wellinks:registry=https://npm.pkg.github.com
```
3. replace <YOUR_GIT_AUTH_TOKEN> with the token you copied to your clipboard
4. run `yarn add @wellinks/wellinks-component-library`
5. the repo should install
## Known issues
1. Sass isn't rendering in Storybook
1. MaterialButton component is broken. It uses an invalid hook call.