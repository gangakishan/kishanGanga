export default interface Provider {
    name: string;
    id: number;  
  }