import { createSlice } from '@reduxjs/toolkit';

const uiSlice = createSlice({
  name: 'ui',
  initialState: { formState: "unchanged"},
  reducers: {    
    showRouteLeaveDialogue(state, action) {
      state.formState = action.payload.formState;
    }
    },  
});

export const uiActions = uiSlice.actions;

export default uiSlice;
