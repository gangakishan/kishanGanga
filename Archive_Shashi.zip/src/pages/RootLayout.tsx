import { Outlet, useLocation,UNSAFE_NavigationContext ,unstable_usePrompt } from "react-router-dom";
import Footer from "../components/Footer/Footer";
import Header from "../components/Header/Header";
import React, { Component ,useEffect } from "react";
import ConfirmDialog from "../components/UIComponents/ConfirmDialogue";
import { useSelector } from 'react-redux';
import type { History } from 'history';

  function RootLayout(){
     //const navigation = useNavigation();

    //  useEffect(() => {

    //  },[formHasChanges])
  
    return (
      <>
        <div className="App">
          <Header />
          <main>
             {/* {navigation.state === 'loading' && <p>Loading...</p>}  */}
            <Outlet />   
            <ConfirmDialog />
          </main>
          <Footer />
        </div>
      </>
    );
  }


export default RootLayout;


