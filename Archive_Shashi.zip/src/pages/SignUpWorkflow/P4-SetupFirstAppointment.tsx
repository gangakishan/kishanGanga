import SetupFirstAppointment from "../../components/SignUpWorkflow/P4-SetupFirstAppointment";

function FirstAppointmentPage(){    

    return <SetupFirstAppointment />


}
export default FirstAppointmentPage;