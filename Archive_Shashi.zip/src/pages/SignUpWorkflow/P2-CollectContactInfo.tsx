import CollectContactInfo from "../../components/SignUpWorkflow/P2-CollectContactInfo";

function ContactPage(){    

    return <CollectContactInfo />

}
export default ContactPage;