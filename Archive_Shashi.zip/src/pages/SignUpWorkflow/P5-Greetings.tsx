import Greetings from "../../components/SignUpWorkflow/P5-Greetings";

function GreetingsPage(){    

    return <Greetings />


}
export default GreetingsPage;