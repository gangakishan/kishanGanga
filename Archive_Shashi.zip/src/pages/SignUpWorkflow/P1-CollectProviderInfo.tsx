import { useLoaderData } from "react-router-dom";
import CollectProviderInfo from "../../components/SignUpWorkflow/P1-CollectProviderIno";
import Provider from "../../Interfaces/Providers";
function ProviderInfoPage(){    

    const privderInfo:Array<Provider> = useLoaderData() as Array<Provider>;   
   
    return <CollectProviderInfo provders={privderInfo} />


}
export default ProviderInfoPage;

export async function loader() {
    const response = await fetch('Providers.json'); // fetch('http://localhost:8080/events');
  
    if (!response.ok) {
      // ...
    } else {
        console.log(response);
      return response;
    }
  }