import CollectCredentials from "../../components/SignUpWorkflow/P3-CollectCredentials";

function CredentialsPage(){    

    return <CollectCredentials />


}
export default CredentialsPage;