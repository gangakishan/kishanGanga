import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./App.scss";
import ErrorPage from "./pages/Error";
import RootLayout from "./pages/RootLayout";
import React, { Component } from "react";
import ProviderInfoPage, { loader as providersLoader } from "./pages/SignUpWorkflow/P1-CollectProviderInfo";
import ContactPage from "./pages/SignUpWorkflow/P2-CollectContactInfo";
import CredentialsPage from "./pages/SignUpWorkflow/P3-CollectCredentials";
import FirstAppointmentPage from "./pages/SignUpWorkflow/P4-SetupFirstAppointment";
import GreetingsPage from "./pages/SignUpWorkflow/P5-Greetings";

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    errorElement: <ErrorPage />,
    children: [
      { 
        index: true, 
       // path: "providerInfo",
        element: <ProviderInfoPage />,
        loader: providersLoader
      },
      {path: 'contactInfo', element: <ContactPage/>},
      {path: 'credentials', element: <CredentialsPage/>},
      {path: 'setupFirstAppointment', element: <FirstAppointmentPage/>},
      {path: 'congratulations', element: <GreetingsPage/>},
    ],
  },
]);


class App extends React.Component {
  render() {
    return <RouterProvider router={router} />;
  }
}

export default App;
