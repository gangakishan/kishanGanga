import Box from '@mui/material/Box';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Stepper from '@mui/material/Stepper';

const steps = [
  {step:'Is Wellinks in your plan?', text:'First, let’s find out if we partner with your health insurance.'},
  {step:'Add your contact info', text:'Tell us where to send your Welcome Kit.'},
  {step:'Secure your account', text:'Almost done! Add an email and a password.'},
  {step:'Set up your first session', text:'Pick a day and time for a 45-minute session with your Health Coach.'},
  {step:'Congratulations', text:'You are all set up.'}
]; 

export default function LinearStepper({activeStep}:{activeStep:number}) {
  return (
    <Box sx={{  marginBotton: '50px' }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((item) => (
          <Step key={item.step}>
            <StepLabel></StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
}