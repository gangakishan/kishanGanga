import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import styles from "./ConfirmDialogue.module.scss";
import { useSelector,useDispatch } from 'react-redux';
import { uiActions } from "../../store/ui-slice";


export default function ConfirmDialog(props: any) {
  const dispatch = useDispatch();
  const formStatus =   useSelector((state:any) => state.ui.formState);
  //const [formState, setFormState] = React.useState<"unchanged" | "modified" | "saving">("unchanged");
const[isOpen, setOpen] = React.useState(false);
 
  const handleClose = () => {
    //setFormState('unchanged');
    dispatch(uiActions.showRouteLeaveDialogue({ formState: "unchanged" }));
  };

  React.useEffect(() => {
    // the handler for actually showing the prompt
    
    const handler = (event: BeforeUnloadEvent) => {
      
      event.preventDefault();
      event.returnValue = "";
      setOpen(true);
    };

    // if the form is NOT unchanged, then set the onbeforeunload
    if (formStatus !== "unchanged") {
      window.addEventListener("beforeunload", handler);
      //setOpen(true);
      // clean it up, if the dirty state changes
      return () => {
        window.removeEventListener("beforeunload", handler);
        setOpen(false);
      };
    }
    // since this is not dirty, don't do anything
    return () => { setOpen(false);};
  }, [formStatus, isOpen]);

  
  return (
    <div>
      <Dialog
        open={isOpen}        
        className={styles.dialogBox}
        aria-labelledby="responsive-dialog-title"
      >
        <DialogTitle className={styles.titleText} id="responsive-dialog-title">
          {"Leave site?"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText className={styles.contentText}>
            Your data will not be saved if you leave this page.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            className={styles.leaveBtn}
            variant="contained"
            disableRipple
            onClick={handleClose}
            autoFocus
          >
            Leave
          </Button>
          <Button
            className={styles.cancelBtn}
            variant="outlined"
            autoFocus
            disableRipple
            onClick={handleClose}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
function dispatch(arg0: { payload: any; type: "ui/showRouteLeaveDialogue"; }) {
  throw new Error("Function not implemented.");
}

