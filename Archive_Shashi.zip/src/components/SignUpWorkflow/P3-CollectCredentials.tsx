import React from "react";
import SignupHeader from "./SingupHeader";

function CollectCredentials() {
  const pageTitle: string = " Secure your account";
  const pageDescription = "Almost done! Add an email and a password.";

  return <SignupHeader title={pageTitle} description={pageDescription} activeStepNumber={2}/>;
}

export default CollectCredentials;
