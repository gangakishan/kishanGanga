import React from "react";
import SignupHeader from "./SingupHeader";

function SetupFirstAppointment() {
  const pageTitle: string = "Set up your first session";
  const pageDescription = "Pick a day and time for a 45-minute session with your Health Coach.";

  return <SignupHeader title={pageTitle} description={pageDescription} activeStepNumber={3} />;
}

export default SetupFirstAppointment;
