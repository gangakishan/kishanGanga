import {
  Autocomplete,
  Button,
  Checkbox,
  Container,
  FormControl,
  FormControlLabel,
  FormGroup,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import SignupHeader from "./SingupHeader";
import styles from "./P1-CollectProviderIno.module.scss";
import Provider from "../../Interfaces/Providers";
import { unstable_usePrompt as usePrompt } from "react-router-dom";
import React, { useEffect, useState } from "react";
import ConfirmDialog from "../UIComponents/ConfirmDialogue";
import { Button as WButton } from "@wellinks/wellinks-component-library";
import { useDispatch } from "react-redux";
import { uiActions } from "../../store/ui-slice";
import { useCallbackPrompt } from "../../hooks/useCallbackPrompt";

function CollectProviderInfo({ provders }: { provders: Array<Provider> }) {
  const [value, setValue] = useState<string>("");

  const dispatch = useDispatch();
  //const [isFormmodified, setIsFormmodified] = React.useState(false);
  const handleInputChange = (e: any) => {
    if (e.target.value !== "") {
      dispatch(uiActions.showRouteLeaveDialogue({ formState: "modified" }));
    } else {
      dispatch(uiActions.showRouteLeaveDialogue({ formState: "unchanged" }));
    }
    setValue(e.target.value);
  };

  console.log(provders);
  const pageTitle: string = "Is Wellinks in your plan?";
  const pageDescription =
    "First, let’s find out if we partner with your health insurance.";
  const proversinfo = provders;
  return (
    <>
       <SignupHeader
        title={pageTitle}
        description={pageDescription}
        activeStepNumber={0}
      />
      <div className={styles.form}>
        <Container maxWidth="sm" className={styles.container}>
          <div>
            <h4 className={styles.title}>Member Information</h4>
            <span className={styles.titleContent}>
              Enter the information as it is on your insurance card(s) to see if
              your plan is eligible.{" "}
            </span>
          </div>
          <div>
            <span className={styles.formlabel}>My Insurance Company</span>
            <Autocomplete
              disablePortal
              id="combo-box-demo"
              options={provders.map((option: Provider) => option.name)}
              sx={{ width: 300 }}
              renderInput={(params) => <TextField {...params} />}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <h3 className={styles.formCheckBoxLable}>
              Primary Insurance Holder Information
            </h3>
            <FormGroup>
              <FormControlLabel
                control={<Checkbox defaultChecked onChange={handleInputChange} />}
                label="I am not the primary insurance policy holder. I am a dependent."
              />
            </FormGroup>
          </div>
          <FormControl fullWidth>
            <span className={styles.titleContent}>Insurance ID Number </span>
            <TextField name="InsurenceId" onChange={handleInputChange} />
          </FormControl>
          <div>
            <FormControl className={styles.FormControl}>
              <span className={styles.titleContent}>First Name </span>
              <TextField name="firstName" onChange={handleInputChange} />
            </FormControl>
            <FormControl>
              <span className={styles.titleContent}>Last Name </span>
              <TextField name="lastName" onChange={handleInputChange} />
            </FormControl>
          </div>
          <FormControl className={styles.FormControl}>
            <span className={styles.titleContent}>Preferred Name </span>
            <TextField name="preferredName" onChange={handleInputChange}/>
            <span className={styles.titleContentSuggestion}>
              If different from your firstname
            </span>
          </FormControl>
          <FormControl>
            <span className={styles.titleContent}>Date of Birth </span>
            <TextField name="dob" onChange={handleInputChange}/>
            <span className={styles.titleContentSuggestion}>
              Type (MM-DD-YYYY) or use calendar icon to select.
            </span>
          </FormControl>
          {/* <FormControl>
              <span className={styles.titleContent}>Date of Birth  new</span>
              { <BasicDatePicker /> }
              <span className={styles.titleContentSuggestion}>Type (MM-DD-YYYY) or use calendar icon to select.</span>
          </FormControl> */}
          <FormControl fullWidth>
            <span className={styles.titleContent}>Gender</span>
            <Select
              labelId="gender"
              name="gender"
              value="Male"
              onChange={handleInputChange}
            >
              <MenuItem value={10}>Male</MenuItem>
              <MenuItem value={20}>Female</MenuItem>
            </Select>
          </FormControl>
          <FormControl>
            <span className={styles.titleContent}>Please Self-describe </span>
            <TextField id="sefDescribe" onChange={handleInputChange} />
          </FormControl>
          <div className="form-group-button">
            <WButton label={"Continue"} />
          </div>

          {/* <div className={styles.timepickercontainer}>
<div className={styles.trianglepointer}></div>
<div className={styles.timepicker}> </div>
</div> */}
        </Container>
      </div>
    </>
  );
}

export default CollectProviderInfo;

function useSelector(arg0: (state: any) => any) {
  throw new Error("Function not implemented.");
}

function dispatch(arg0: { payload: any; type: "ui/showRouteLeaveDialogue" }) {
  throw new Error("Function not implemented.");
}
