import React from "react";
import SignupHeader from "./SingupHeader";

function CollectContactInfo() {
  const pageTitle: string = "Add your contact info";
  const pageDescription = "Tell us where to send your Welcome Kit.";

  return <SignupHeader title={pageTitle} description={pageDescription} activeStepNumber={1} />;
}

export default CollectContactInfo;