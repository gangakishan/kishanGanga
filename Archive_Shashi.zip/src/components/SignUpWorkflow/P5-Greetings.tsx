import React from "react";
import SignupHeader from "./SingupHeader";

function Greetings(){
  const pageTitle: string = "Congratulations";
  const pageDescription = "You are all set up.";
  return <SignupHeader title={pageTitle} description={pageDescription} activeStepNumber={4} />;    
}

export default Greetings;