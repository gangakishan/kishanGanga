import { Outlet, useNavigation } from 'react-router-dom';
import Footer from '../components/Footer';
import Header from '../components/Header';
import LinearStepper from '../components/UIComponents/LinearStepper';

function RootLayout() {
  // const navigation = useNavigation();

  return (
    <>
    <div className="App">
      <Header />
      <main>      
      
        {/* {navigation.state === 'loading' && <p>Loading...</p>} */}
        <Outlet />
      </main>
      <Footer />
    </div>
    </>
  );
}

export default RootLayout;
