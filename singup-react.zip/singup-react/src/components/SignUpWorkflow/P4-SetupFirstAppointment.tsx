import React from "react";
import LinearStepper from "../UIComponents/LinearStepper";

function SetupFirstAppointment(){
    return (
      
        <div className="section-hero-about wf-section">
        <div className="container">
          <div className="about-hero-wrap">
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 className="h1-hero black-color-text">
            Set up your first session
            </h1>
            <p className="subtext-home large black-color-text text-opacity-80">Pick a day and time for a 45-minute session with your Health Coach.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <LinearStepper />  
          </div>
        </div>
      </div>     
     
    );
}

export default SetupFirstAppointment;