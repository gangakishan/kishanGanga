import React from "react";
import LinearStepper from "../UIComponents/LinearStepper";

function CollectCredentials(){
    return (
      
        <div className="section-hero-about wf-section">
        <div className="container">
          <div className="about-hero-wrap">
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 className="h1-hero black-color-text">
            Secure your account
            </h1>
            <p className="subtext-home large black-color-text text-opacity-80">Almost done! Add an email and a password.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <LinearStepper />  
          </div>
        </div>
      </div>     
     
    );
}

export default CollectCredentials;