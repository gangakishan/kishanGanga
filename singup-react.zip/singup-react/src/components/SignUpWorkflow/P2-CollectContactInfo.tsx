import React from "react";
import LinearStepper from "../UIComponents/LinearStepper";

function CollectContactInfo(){
    return (
      
        <div className="section-hero-about wf-section">
        <div className="container">
          <div className="about-hero-wrap">
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 className="h1-hero black-color-text">
            Add your contact info
            </h1>
            <p className="subtext-home large black-color-text text-opacity-80">Tell us where to send your Welcome Kit.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <LinearStepper />  
          </div>
        </div>
      </div>     
     
    );
}

export default CollectContactInfo;