import React from "react";
import LinearStepper from "../UIComponents/LinearStepper";


function CollectProviderInfo(){
    return (
      
        <div className="section-hero-about wf-section">
          
        <div className="container">
          <div className="about-hero-wrap">
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 className="h1-hero black-color-text">
              Is Wellinks in your plan?
            </h1>
            <p className="subtext-home large black-color-text text-opacity-80">First, let’s find out if we partner with your health insurance.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <LinearStepper />  
          </div>
        </div>
      </div>     
     
    );
}

export default CollectProviderInfo;