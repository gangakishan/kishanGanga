import React from "react";
import LinearStepper from "../UIComponents/LinearStepper";

function Greetings(){
    return (
      
        <div className="section-hero-about wf-section">
        <div className="container">
          <div className="about-hero-wrap">
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 className="h1-hero black-color-text">
            Congratulations
            </h1>
            <p className="subtext-home large black-color-text text-opacity-80">You are all set up.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <LinearStepper />  
          </div>
        </div>
      </div>     
     
    );
}

export default Greetings;