import { Outlet, useNavigation, createBrowserRouter, RouterProvider } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import  './App.scss';
import ErrorPage from './pages/Error';
import CollectProviderInfo from './components/SignUpWorkflow/P1-CollectProviderIno';
import CollectContactInfo from './components/SignUpWorkflow/P2-CollectContactInfo';
import CollectCredentials from './components/SignUpWorkflow/P3-CollectCredentials';
import SetupFirstAppointment from './components/SignUpWorkflow/P4-SetupFirstAppointment';
import Greetings from './components/SignUpWorkflow/P5-Greetings';
import RootLayout from './pages/RootLayout';

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    errorElement: <ErrorPage />,
    children: [
      { index: true, path: "/providerInfo", element: <CollectProviderInfo /> },
      {path: '/contactInfo', element: <CollectContactInfo/>},
      {path: '/credentials', element: <CollectCredentials/>},
      {path: '/setupFirstAppointment', element: <SetupFirstAppointment/>},
      {path: '/congratulations', element: <Greetings/>},
    ],
  },
]);

function App() {
  return (
    <RouterProvider router={router}/>
  );
}

export default App;
